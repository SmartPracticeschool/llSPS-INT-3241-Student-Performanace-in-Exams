from flask import Flask, request, render_template
from joblib import load
from itertools import chain
from gevent.pywsgi import WSGIServer
import os
app = Flask(__name__) 
model = load('Student Grade Prediction Model.txt')
@app.route('/')
def home():
    return render_template('1st page.html')

@app.route('/page_2',methods=['post'])
def page_2():
    my_prediction=''
    x_test = [[x for x in request.form.values()]]
    l=[[]]
    d={'Male':1.0,'Female':0.0,
       'Group A':[1.0,0.0,0.0,0.0,0.0],'Group B':[0.0,1.0,0.0,0.0,0.0],'Group C':[0.0,0.0,1.0,0.0,0.0],'Group D':[0.0,0.0,0.0,1.0,0.0],'Group E':[0.0,0.0,0.0,0.0,1.0],
       'High School':[0.0,0.0,1.0,0.0,0.0,0.0],'Bachelor\'s Degree':[0.0,1.0,0.0,0.0,0.0,0.0],'Associate\'s Degree':[1.0,0.0,0.0,0.0,0.0,0.0],'Master\'s Degree':[0.0,0.0,0.0,0.1,0.0,0.0],'Some College':[0.0,0.0,0.0,0.0,0.1,0.0],'Some High School':[0.0,0.0,0.0,0.0,0.0,0.1],
       'Standard':[0.0,1.0],'Free/Reduced':[1.0,0.0],
       'Completed':[1.0,0.0],'None':[0.0,1.0]}
    for i in x_test[0]:
        try:
            l[0].insert(0,d[i])
        except:
            l[0].append(i)
    l=list(chain(*l))
    temp=[]
    for i in l[:-3]:
        try:
            if len(i)!=0:
                for j in i:
                    temp.append(j)
        except:
            temp.append(i)
    for i in l[-3:]:
        temp.append(int(i))
    l=[[]]
    l[0]=temp
    i = model.predict(l)
    if i==0:
        my_prediction='A'
    elif i==1:
        my_prediction='A+'
    elif i==2:
        my_prediction='B'
    elif i==3:
        my_prediction='B+'
    elif i==4:
        my_prediction='O'
    else:
        my_prediction='Re-Appear'
    if i==5:
        return render_template('result_page_fail.html',prediction = my_prediction)
    return render_template('result_page.html',prediction = my_prediction)
if __name__ == "__main__":
    port = int(os.getenv('PORT', 8000))
    #app.run(host='0.0.0.0', port=port, debug=True)
    http_server = WSGIServer(('0.0.0.0', port), app)
    http_server.serve_forever()
    #app.run(debug=True)
